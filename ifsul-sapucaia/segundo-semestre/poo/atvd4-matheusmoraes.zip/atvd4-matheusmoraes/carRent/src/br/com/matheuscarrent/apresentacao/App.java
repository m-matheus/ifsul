package br.com.matheuscarrent.apresentacao;

import java.util.List;
import java.util.Scanner;

import br.com.matheuscarrent.model.Usuario;
import br.com.matheuscarrent.model.Veiculo;
import br.com.matheuscarrent.persistencia.UsuarioDAO;
import br.com.matheuscarrent.persistencia.VeiculoDAO;

public class App {

    public static void main(String[] args) {
        Scanner kb = new Scanner(System.in);
        
        boolean running = true;
        do {
            System.out.println("1 - Cadastrar novo usuário");
            System.out.println("2 - Login");
            int option = kb.nextInt();
            Usuario u = null;
            Veiculo v = null;
            UsuarioDAO uDAO;
            VeiculoDAO vDAO;
            switch (option) {
                case 1:
                    u = new Usuario();
                    System.out.println("Digite seu nome: ");
                    u.setNome(kb.next());
                    System.out.println("Digite seu email: ");
                    u.setEmail(kb.next());
                    System.out.println("Digite sua senha: ");
                    u.setSenha(kb.next());
                    uDAO = new UsuarioDAO();
                    uDAO.salvar(u);
                    break;
                
                case 2:
                    u = new Usuario();
                    System.out.println("Digite seu email: ");
                    u.setEmail(kb.next());
                    System.out.println("Digite sua senha: ");
                    u.setSenha(kb.next());
                    uDAO = new UsuarioDAO();
                    Usuario usuarioLogado = uDAO.fazerLogin(u.getEmail(), u.getSenha());
                    if (usuarioLogado != null) {
                        // O login foi bem-sucedido
                        System.out.println("Login bem-sucedido! Bem-vindo, " + usuarioLogado.getNome());
                        do {
                            option = 0;
                            System.out.println("1 - Cadastrar novo veiculo");
                            System.out.println("2 - Visualizar veiculos cadastrados"); 
                            System.out.println("3 - Editar um veiculo já existente"); 
                            option = kb.nextInt();
                            switch (option) {
                                case 1:
                                    v = new Veiculo();
                                    System.out.println("Digite a placa do seu veiculo: ");
                                    v.setPlaca(kb.next());
                                    System.out.println("Digite o modelo do veiculo: ");
                                    v.setModelo(kb.next());
                                    System.out.println("Digite a cor do veiculo: ");
                                    v.setCor(kb.next());
                                    System.out.println("Digite o ano do veiculo: ");
                                    v.setAno(kb.nextInt());
                                    
                                    // associa o ID do usuário logado ao veículo
                                    v.setId(usuarioLogado.getId());
                                    
                                    vDAO = new VeiculoDAO();
                                    vDAO.cadastrarVeiculo(v);
                                    System.out.println("Veiculo cadastrado com sucesso!");
                                    break;
                                case 2:
                                // Listar todos os veículos cadastrados
                                vDAO = new VeiculoDAO();
                                List<Veiculo> veiculos = vDAO.buscarVeiculosUsuario(usuarioLogado.getId());
                                if (!veiculos.isEmpty()) {
                                    System.out.println("Veículos cadastrados:");
                                    for (Veiculo veiculo : veiculos) {
                                        System.out.println("ID: " + veiculo.getId());
                                        System.out.println("Placa: " + veiculo.getPlaca());
                                        System.out.println("Modelo: " + veiculo.getModelo());
                                        System.out.println("Cor: " + veiculo.getCor());
                                        System.out.println("Ano: " + veiculo.getAno());
                                        System.out.println();
                                    }
                                } else {
                                    System.out.println("Nenhum veículo cadastrado.");
                                }
                                    break;
                                
                                case 3:

                                    break;

                                default:
                                    break;
                            }
                        }
                        while (usuarioLogado != null);
                    } else {
                        // O login falhou
                        System.out.println("Login falhou. Verifique suas credenciais.");
                    }
                default:
                    break;
            }
        }
        while (running == true);
        kb.close();

        
    }
}
